import {plannedStatus} from './forecast';
export const nextDate=(day:string)=>new Date(Date.parse(day+'T12:00:00Z')+86400000).toISOString().slice(0,10);
export function dayAbsencePlan(users:any[],absences:any[],day:string){
const start=day+'T00:00',end=nextDate(day)+'T00:00';const points=new Set([start,end]);
for(const a of absences)for(const t of [a.start,a.end])if(t>start&&t<end)points.add(t);
for(const u of users){const work=typeof u.work==='string'?JSON.parse(u.work):u.work||[];for(const w of work)for(const time of [w.start,w.end])points.add(day+'T'+time);}
const sorted=[...points].sort();return users.map(u=>{const intervals:any[]=[];for(let i=0;i<sorted.length-1;i++){const from=sorted[i],to=sorted[i+1];const status=plannedStatus(u,absences,from);if(status.available)continue;const previous=intervals[intervals.length-1];if(previous&&previous.to===from&&previous.reason===status.reason)previous.to=to;else intervals.push({from,to,reason:status.reason});}return {...u,intervals};}).filter(u=>u.intervals.length).sort((a,b)=>a.name.localeCompare(b.name,'cs'));
}
export const dayMinute=(stamp:string,day:string)=>stamp.slice(0,10)>day?1440:Number(stamp.slice(11,13))*60+Number(stamp.slice(14,16));
export const intervalTime=(stamp:string,day:string)=>stamp.slice(0,10)>day?'24:00':stamp.slice(11,16);
