// One-time, owner-authorized roster import. No plaintext password is stored.
const members=[
  {
    "id": "92f8928e-e7a8-48a0-bbeb-c148bb633705",
    "username": "beranek.jaromir",
    "name": "Beránek Jaromír",
    "password": "4826f8c5-e486-4705-b3ce-952cee32c901:cdbbb1d28be28cc9d18cbf7bc42f049d6013550c57e6c712b5fffcf0f04b5da5",
    "roles": "[\"hasic\",\"strojnik\",\"mp\"]"
  },
  {
    "id": "7d1cc363-7030-4b60-a566-140f74972ec9",
    "username": "beranek.lukas",
    "name": "Beránek Lukáš",
    "password": "e3aa63fc-85e4-49e8-afe8-13560ea516bd:7745b9101d75c4ff6ae47da052e8597d1064c4baafe6c4d05ae5a827394b186a",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\"]"
  },
  {
    "id": "24464d78-459e-4e8f-a42f-8bf0c970d2cc",
    "username": "boruvka",
    "name": "Borůvka Pavel",
    "password": "3e81654a-ba66-495f-bd54-cca02408ba54:57f736bf72fff91655a2f8dd830695e9203ff9d303fcc833ff5c06f891156772",
    "roles": "[\"hasic\",\"strojnik\",\"mp\"]"
  },
  {
    "id": "7feaf394-5f74-40c3-808f-54c7173d2804",
    "username": "budinsky",
    "name": "Budinský Tomáš",
    "password": "851ca28a-8e2c-445e-b24e-e92b9ad95f50:9641ad641dfa72324ae6dcf9073078bfd990e47077eb059650a118b2de4a728a",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\"]"
  },
  {
    "id": "bd9baf8f-ea44-4149-999c-6527ddb1f1d6",
    "username": "cizik.jakub",
    "name": "Čížik Jakub",
    "password": "77dc862e-5ff0-431b-93ca-2d383b3fe1e5:41e049f253327a6e2d3f099ecd795277eb4b149a31f9e02853afd85c40edc082",
    "roles": "[\"hasic\",\"dt\"]"
  },
  {
    "id": "3f8169aa-2d83-42ca-a693-8080b0bfedca",
    "username": "cizik.matej",
    "name": "Čížik Matěj",
    "password": "8333d653-aba3-4c09-8a18-9251cc2e2501:e0643cfb0257db5c12265d31e8d99768bc3d24ea4eab2da6e5a6cc3557a04269",
    "roles": "[\"hasic\",\"dt\"]"
  },
  {
    "id": "7d846b28-d4d9-4730-b2f7-bfb86e85f518",
    "username": "cermakova",
    "name": "Čermáková Mirka",
    "password": "6dbe8a60-a868-4a4c-8bbc-2a7906ec027a:76eda25fa3cfd76e7209392d4c9aca3bbeffdbed70352ee22ec8c132dc223a3a",
    "roles": "[\"hasic\"]"
  },
  {
    "id": "2a4ea352-4acc-46a0-bfa7-b174c3025c01",
    "username": "dosek",
    "name": "Došek Antonín",
    "password": "eb88b414-491d-42af-8626-f55f2ec6fb48:26ad9171e942658d36be9d82f8cf4873c141962ee2e9bdf9b92e90afa84da6d5",
    "roles": "[\"hasic\",\"strojnik\"]"
  },
  {
    "id": "ae1f742a-b7aa-4045-8a95-fccc8fafe9bb",
    "username": "dvoracek",
    "name": "Dvořáček Martin",
    "password": "cfb12017-7224-40cc-8dcd-7d686b8df6bb:ece7b6c2514a85f3c497a00e33da4e1d752cd9f08b2f5e6b700de63cf0e03a2a",
    "roles": "[\"hasic\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "50245fae-18f3-45bc-ba9b-47f24f64a6d0",
    "username": "fulka",
    "name": "Fulka Jiří",
    "password": "78f390fb-008f-401d-aaf1-4f8e95fa86f5:873be6cd9fa2ae11f6a5a790e47fac416e055a32b1a38e0e410a320e00a57909",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "d275489b-50b9-412f-a12e-f86d974d0c17",
    "username": "horak",
    "name": "Horák Matyáš",
    "password": "2c20414b-edd4-4be7-861a-8b04a662722a:1177269e64eaa78c30e6dcae7759c6e519911c735d03f4723f1725c508edddb8",
    "roles": "[\"hasic\",\"dt\"]"
  },
  {
    "id": "a1316298-d574-499f-a328-afd0a5dead76",
    "username": "jary.michal",
    "name": "Jarý Michal",
    "password": "ec0d01b6-d242-4556-855a-e01b3d6f464d:242560c196f57157b6f1156e3b34f636ef5f6e78c5ebfa36c2cbb42811934a34",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\"]"
  },
  {
    "id": "46011391-7595-439d-9ba6-dea2d4b7b51e",
    "username": "jary.petr",
    "name": "Jarý Petr",
    "password": "c5691c27-08e0-4237-91fb-2877e5dced11:028f7292e97b4b3db8fd14ac248afb44e46afa49bd3e92748207b72cef888c21",
    "roles": "[\"hasic\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "b4eb350e-2cfa-45f5-9e7c-e93104573bef",
    "username": "jirousek",
    "name": "Jiroušek Zdeněk",
    "password": "9c467a8b-346f-4883-97d4-2e9384291148:ffaf869804d7160c031fdca74e2dffcf60abba0e0f307ad278f19582df27898c",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "c3617d6e-c19b-4191-b259-4e5d4d18dcf1",
    "username": "kleprlik",
    "name": "Kleprlík Aleš",
    "password": "739d5a3b-585d-40f8-bb66-7fab4907166c:c8d1b480a0f5fdfe5f35fe0a36b36d1782e4c38a26508be83a09d7adf8cca4b9",
    "roles": "[\"hasic\",\"dt\"]"
  },
  {
    "id": "189e510b-7030-4461-bde9-305ccdb287f5",
    "username": "kopera",
    "name": "Kopera Ondřej",
    "password": "feca4601-cf79-4b5e-821a-4b909f08c22e:b78ddeefa349acb713760a992592503205f2b0cd44165c52f28ea4f2451e874f",
    "roles": "[\"hasic\",\"dt\"]"
  },
  {
    "id": "165c9ffa-af72-4fce-af85-f2b9602a8059",
    "username": "munzar",
    "name": "Munzar Václav",
    "password": "298162e1-d602-4dd6-97d2-b13108a9c200:325f59f849b0715cb5ba7d36329e44b65981da57c8eca522532b01c0ee468d49",
    "roles": "[\"hasic\"]"
  },
  {
    "id": "d61f0e18-45dd-4410-aefa-b5dc99e99efc",
    "username": "petira.jiri",
    "name": "Petira Jiří",
    "password": "c087e902-9274-49b6-a215-c6f0f765b959:8a03fadeb0ca85d70c8629c63f0479b96400a024e818df8588f1d4d1ae806280",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"velitel\"]"
  },
  {
    "id": "8134e17d-a1bc-4cc3-b96b-03a71972b954",
    "username": "petira.jiri.ml",
    "name": "Petira Jiří ml.",
    "password": "0aea2624-ea21-4b64-bd75-d63d11752c15:7add7e64bd89d9b524d8592ad9327ded26a395ccfc41f3fb1c65a5b2def0a6f7",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "6c6656fd-bf91-43f9-ad08-b6411d3ec818",
    "username": "petira.tomas",
    "name": "Petira Tomáš",
    "password": "c4eff479-db65-49ac-ae30-34cfb919857d:7a769cf2e031e4a425fe8195e0c6b281b2eef40e383781600bcff2bcaca728cb",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "1f8f0d49-8521-491f-af96-3406ad5a0e8a",
    "username": "polc",
    "name": "Polc Ondřej",
    "password": "017f771c-f42b-4337-93b9-cf1e7c92f631:c11f2cc7dd757142e0f3a6f64513ba42da1efe01db4d17448da8b8acc21dd6f9",
    "roles": "[\"hasic\",\"dt\"]"
  },
  {
    "id": "fe230947-8472-4b48-8621-33aa4ecec619",
    "username": "sochor",
    "name": "Sochor Jan",
    "password": "a95aebde-43f2-4a35-96e3-4b7c2245f0fa:f31547a38f25735abb2e6c84ffe1c3ebfe7e64157a0e9c9cd82a2ed984f19996",
    "roles": "[\"hasic\",\"dt\"]"
  },
  {
    "id": "38bf664e-32d0-476d-8566-66b90a16a918",
    "username": "soukup.ladislav",
    "name": "Soukup Ladislav",
    "password": "7847a9db-207a-4aa7-8972-8e759805f95f:b90a3db9523bfbc0df3e9eca47f59f2b7dca24675e5ef1ca6f029924a60c4696",
    "roles": "[\"hasic\",\"mp\",\"dt\"]"
  },
  {
    "id": "7284787a-9a39-4a33-b50a-bf24ffa43a15",
    "username": "soukup.lukas",
    "name": "Soukup Lukáš",
    "password": "c938228a-4845-4ae9-a1c5-efc9540b5911:57860588a0b573686ba0cb9e7b74939a89926bedb4a7644857ca304e05c00201",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "0f7e00b0-544b-4bf0-a5ca-503b6a7e24d4",
    "username": "strachota",
    "name": "Strachota Radek",
    "password": "1c664c59-5cbb-4e62-b4c4-45f94b1ccc37:faaf6047691c21e9e596c8722f5200cf7e20ef42db5103c6748fae50d4e9de14",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\",\"velitel\"]"
  },
  {
    "id": "e9947374-2154-4d97-b5ce-9b97dc4b0d76",
    "username": "svihalek",
    "name": "Švihálek Jiří ml.",
    "password": "18902af6-ca2e-4fc7-b12f-416634e1ee19:b2e2b5107daa5d5db55e402ade1b06b9a8ed5033f20e1f8d78c4e08a5a2570f3",
    "roles": "[\"hasic\",\"mp\",\"velitel\"]"
  },
  {
    "id": "c67642eb-b368-48b8-86b1-eef92d122f23",
    "username": "turek",
    "name": "Turek Radko",
    "password": "a49280dc-751e-40ec-80f2-f3c7d15538db:2e197a8954b5922f4aac95b74a9f6cbc42f04c4ffb2e2416f44e663781971437",
    "roles": "[\"hasic\"]"
  },
  {
    "id": "4fff71ea-3786-42df-99f5-cb9c0815b682",
    "username": "vit",
    "name": "Vít Martin",
    "password": "ba88a710-6ea9-4045-864b-5e8084314f5c:989745f333062c9acb8ff6f7bab49df70dec904aa6ae425de0ce0fc0f3a3ea28",
    "roles": "[\"hasic\",\"strojnik\",\"mp\",\"dt\",\"velitel\"]"
  }
];
export async function importRoster(db:any){
const key='roster_import_20261001';
if(await db.prepare('SELECT value FROM settings WHERE key=?').bind(key).first())return;
await db.batch([...members.map(m=>db.prepare('INSERT OR IGNORE INTO users(id,username,name,password,roles,admin,override,must_change_password) VALUES(?,?,?,?,?,0,?,1)').bind(m.id,m.username,m.name,m.password,m.roles,'no')),db.prepare('INSERT OR IGNORE INTO logs(id,at,actor,action) VALUES(?,?,?,?)').bind(key,new Date().toISOString(),'Administrátor','Import 28 členů jednotky a kvalifikací z dodaného seznamu'),db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').bind(key,'done')]);
}
