import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const users=sqliteTable('users',{id:text('id').primaryKey(),username:text('username').notNull().unique(),name:text('name').notNull(),password:text('password').notNull(),mustChangePassword:integer('must_change_password').notNull().default(0),roles:text('roles').notNull(),admin:integer('admin').notNull().default(0),work:text('work').notNull().default('[]'),override:text('override'),until:text('until'),overridePlan:text('override_plan').notNull().default('[]'),shift:text('shift').notNull().default(''),statusUpdatedAt:text('status_updated_at'),note:text('note').notNull().default('')});
export const absences=sqliteTable('absences',{id:text('id').primaryKey(),userId:text('user_id').notNull(),start:text('start').notNull(),end:text('end').notNull(),reason:text('reason').notNull(),kind:text('kind').notNull().default('absence')});
export const sessions=sqliteTable('sessions',{id:text('id').primaryKey(),userId:text('user_id').notNull(),expires:integer('expires').notNull()});
export const logs=sqliteTable('logs',{id:text('id').primaryKey(),at:text('at').notNull(),actor:text('actor').notNull(),action:text('action').notNull()});
export const attempts=sqliteTable('attempts',{id:text('id').primaryKey(),count:integer('count').notNull(),until:integer('until').notNull()});

export const messages=sqliteTable('messages',{id:text('id').primaryKey(),userId:text('user_id').notNull(),author:text('author').notNull(),body:text('body').notNull(),at:text('at').notNull(),day:text('day').notNull()},table=>[index('messages_day_at_idx').on(table.day,table.at)]);

export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
