import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "JPO Úpice · Dostupnost",
  description: "Dostupnost hasičů, plánování nepřítomnosti a správa jednotky.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="cs" suppressHydrationWarning>
      <body className="antialiased"><script dangerouslySetInnerHTML={{__html:"try{var t=localStorage.getItem('jpo-theme');document.documentElement.dataset.theme=t==='dark'||t==='light'?t:(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')}catch(e){document.documentElement.dataset.theme='light'}"}}/>{children}</body>
    </html>
  );
}
