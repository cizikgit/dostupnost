ALTER TABLE `absences` ADD `kind` text DEFAULT 'absence' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `shift` text DEFAULT '' NOT NULL;