CREATE TABLE `messages` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`author` text NOT NULL,
	`body` text NOT NULL,
	`at` text NOT NULL,
	`day` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `messages_day_at_idx` ON `messages` (`day`,`at`);--> statement-breakpoint
ALTER TABLE `users` ADD `note` text DEFAULT '' NOT NULL;